package com.example.proyectoparqueadero49unab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectoparqueadero49unabApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyectoparqueadero49unabApplication.class, args);
	}

}
